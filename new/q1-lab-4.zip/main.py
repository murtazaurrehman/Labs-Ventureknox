x=int(input("Enter the first number"))
y=int(input("Enter the second number"))
z=int(input("Enter the skip number"))
for i in range(x,y+1,z):
    print(i)
