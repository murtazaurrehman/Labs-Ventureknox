def mur3(x,y):
    sum1=x+y;
    print(sum1)
    
x=int(input("Enter the first number"))
y=int(input("Enter the second number"))
mur3(x,y)
