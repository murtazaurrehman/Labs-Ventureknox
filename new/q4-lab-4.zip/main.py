x=int(input("Enter the number for it's divisors"))
for i in range(1,x):
    y=int()
    y=x%i;
    if y==0:
        print(i);
    