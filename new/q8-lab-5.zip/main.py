x=["Karachi Kings", "Lahore Qalandars" ,"Peshawar Zalmi", "Multan Sultans", "Islamabad United", "Quetta Gladiators"]
for i in range(1,5):
    print("karachi kings vs",x[i])
    
for i in range(2,5):
    print("lahore Qalandars vs",x[i])
for i in range(3,5):
    print("Peshawar Zalmi vs",x[i])
for i in range(4,5):
    print("Multan Sultans vs",x[i])
for i in range(5,6):
    print("Islamabad United vs",x[i])
    