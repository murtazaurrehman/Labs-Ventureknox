house = [["hallway", 11.25],
 ["kitchen", 18.0],
 ["living room", 20.0],
 ["bedroom", 10.75],
 ["bathroom", 9.50]]
x=[]
y=[]
# for i in range(4): 
#     yy=house[i]
#     for j in y:
#         if type(yy[j])==str:
#             y.append(yy[j])
            
#         elif type(yy[j])==float:
#             x.append(yy[j])
for i in house:
    for j in i:
       print(house[0])
   
   
    
# print(x,y)