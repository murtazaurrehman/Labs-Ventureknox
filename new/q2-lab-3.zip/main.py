x=int(input("Please enter your first number"))
y=int(input("Please enter your second number"))
for i in range(x,y+1):
    print(i);
