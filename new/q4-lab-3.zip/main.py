y=int(input("Please enter the number for the table"))
for i in range(1,11):
    z=i*y;
    print(i,"x",y,"=",z)