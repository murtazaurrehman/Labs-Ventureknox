x=[]
y=int(input("Enter the size of your array:"))
for i in range(y):
    zz=int(input("Please enter the numbers in your array:"))
    x.append(zz)
    
x.reverse()
print(x)
    