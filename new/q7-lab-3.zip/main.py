x=int(input("Please enter the number for your factorial"))
z=int(1);
for i in range(1,x+1):
  z=z*i 
print(z)