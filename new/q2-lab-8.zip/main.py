def month(x):
    data=['January','february','March','April','may','june','july','august','september','october','november','december']
    print(data[x-1])
    
x=int(input("please enter the month number"))
month(x)